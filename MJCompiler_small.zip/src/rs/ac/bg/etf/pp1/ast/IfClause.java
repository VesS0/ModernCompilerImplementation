// generated with ast extension for cup
// version 0.8
// 23/5/2018 3:50:52


package rs.ac.bg.etf.pp1.ast;

public class IfClause implements SyntaxNode {

    private SyntaxNode parent;
    private int line;
    private CondOrListEnd CondOrListEnd;

    public IfClause (CondOrListEnd CondOrListEnd) {
        this.CondOrListEnd=CondOrListEnd;
        if(CondOrListEnd!=null) CondOrListEnd.setParent(this);
    }

    public CondOrListEnd getCondOrListEnd() {
        return CondOrListEnd;
    }

    public void setCondOrListEnd(CondOrListEnd CondOrListEnd) {
        this.CondOrListEnd=CondOrListEnd;
    }

    public SyntaxNode getParent() {
        return parent;
    }

    public void setParent(SyntaxNode parent) {
        this.parent=parent;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line=line;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(CondOrListEnd!=null) CondOrListEnd.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(CondOrListEnd!=null) CondOrListEnd.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(CondOrListEnd!=null) CondOrListEnd.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("IfClause(\n");

        if(CondOrListEnd!=null)
            buffer.append(CondOrListEnd.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [IfClause]");
        return buffer.toString();
    }
}
