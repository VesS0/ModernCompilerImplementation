// generated with ast extension for cup
// version 0.8
// 23/5/2018 3:50:52


package rs.ac.bg.etf.pp1.ast;

public class Var implements SyntaxNode {

    private SyntaxNode parent;
    private int line;
    public rs.etf.pp1.symboltable.concepts.Obj obj = null;

    private String varName;
    private OptArrayBrackets OptArrayBrackets;
    private OptValueAssign OptValueAssign;

    public Var (String varName, OptArrayBrackets OptArrayBrackets, OptValueAssign OptValueAssign) {
        this.varName=varName;
        this.OptArrayBrackets=OptArrayBrackets;
        if(OptArrayBrackets!=null) OptArrayBrackets.setParent(this);
        this.OptValueAssign=OptValueAssign;
        if(OptValueAssign!=null) OptValueAssign.setParent(this);
    }

    public String getVarName() {
        return varName;
    }

    public void setVarName(String varName) {
        this.varName=varName;
    }

    public OptArrayBrackets getOptArrayBrackets() {
        return OptArrayBrackets;
    }

    public void setOptArrayBrackets(OptArrayBrackets OptArrayBrackets) {
        this.OptArrayBrackets=OptArrayBrackets;
    }

    public OptValueAssign getOptValueAssign() {
        return OptValueAssign;
    }

    public void setOptValueAssign(OptValueAssign OptValueAssign) {
        this.OptValueAssign=OptValueAssign;
    }

    public SyntaxNode getParent() {
        return parent;
    }

    public void setParent(SyntaxNode parent) {
        this.parent=parent;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line=line;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(OptArrayBrackets!=null) OptArrayBrackets.accept(visitor);
        if(OptValueAssign!=null) OptValueAssign.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(OptArrayBrackets!=null) OptArrayBrackets.traverseTopDown(visitor);
        if(OptValueAssign!=null) OptValueAssign.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(OptArrayBrackets!=null) OptArrayBrackets.traverseBottomUp(visitor);
        if(OptValueAssign!=null) OptValueAssign.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("Var(\n");

        buffer.append(" "+tab+varName);
        buffer.append("\n");

        if(OptArrayBrackets!=null)
            buffer.append(OptArrayBrackets.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(OptValueAssign!=null)
            buffer.append(OptValueAssign.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [Var]");
        return buffer.toString();
    }
}
