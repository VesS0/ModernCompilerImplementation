// generated with ast extension for cup
// version 0.8
// 23/5/2018 3:50:52


package rs.ac.bg.etf.pp1.ast;

public class CondOrLists extends CondOrList {

    private CondOrList CondOrList;
    private CondAndListEnd CondAndListEnd;

    public CondOrLists (CondOrList CondOrList, CondAndListEnd CondAndListEnd) {
        this.CondOrList=CondOrList;
        if(CondOrList!=null) CondOrList.setParent(this);
        this.CondAndListEnd=CondAndListEnd;
        if(CondAndListEnd!=null) CondAndListEnd.setParent(this);
    }

    public CondOrList getCondOrList() {
        return CondOrList;
    }

    public void setCondOrList(CondOrList CondOrList) {
        this.CondOrList=CondOrList;
    }

    public CondAndListEnd getCondAndListEnd() {
        return CondAndListEnd;
    }

    public void setCondAndListEnd(CondAndListEnd CondAndListEnd) {
        this.CondAndListEnd=CondAndListEnd;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(CondOrList!=null) CondOrList.accept(visitor);
        if(CondAndListEnd!=null) CondAndListEnd.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(CondOrList!=null) CondOrList.traverseTopDown(visitor);
        if(CondAndListEnd!=null) CondAndListEnd.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(CondOrList!=null) CondOrList.traverseBottomUp(visitor);
        if(CondAndListEnd!=null) CondAndListEnd.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("CondOrLists(\n");

        if(CondOrList!=null)
            buffer.append(CondOrList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(CondAndListEnd!=null)
            buffer.append(CondAndListEnd.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [CondOrLists]");
        return buffer.toString();
    }
}
