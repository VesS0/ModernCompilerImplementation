// generated with ast extension for cup
// version 0.8
// 23/5/2018 3:50:52


package rs.ac.bg.etf.pp1.ast;

public class AssignExpr implements SyntaxNode {

    private SyntaxNode parent;
    private int line;
    private ExprOrError ExprOrError;

    public AssignExpr (ExprOrError ExprOrError) {
        this.ExprOrError=ExprOrError;
        if(ExprOrError!=null) ExprOrError.setParent(this);
    }

    public ExprOrError getExprOrError() {
        return ExprOrError;
    }

    public void setExprOrError(ExprOrError ExprOrError) {
        this.ExprOrError=ExprOrError;
    }

    public SyntaxNode getParent() {
        return parent;
    }

    public void setParent(SyntaxNode parent) {
        this.parent=parent;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line=line;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ExprOrError!=null) ExprOrError.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ExprOrError!=null) ExprOrError.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ExprOrError!=null) ExprOrError.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("AssignExpr(\n");

        if(ExprOrError!=null)
            buffer.append(ExprOrError.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [AssignExpr]");
        return buffer.toString();
    }
}
