package rs.ac.bg.etf.pp1;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import rs.ac.bg.etf.pp1.ast.*;
import rs.etf.pp1.symboltable.Tab;
import rs.etf.pp1.symboltable.concepts.Obj;
import rs.etf.pp1.symboltable.concepts.Struct;
import rs.etf.pp1.symboltable.structure.SymbolDataStructure;

public class SemanticAnalyzer extends VisitorAdaptor {
	boolean errorDetected = false;
	Obj currentMethod = null, currentAssignObject = null;
	Struct currentDeclTypeStruct = null;
	boolean isCurrentTypeConst = false;
	boolean returnFound = false;
	boolean mainFound = false;
	int nVars;
	
	Logger log = Logger.getLogger(getClass());

	public void report_error(String message, SyntaxNode info) {
		errorDetected = true;
		StringBuilder msg = new StringBuilder(message);
		log.error(msg.toString());
	}

	public void report_info(String message, SyntaxNode info) {
		StringBuilder msg = new StringBuilder(message); 
		log.info(msg.toString());
	}
	
	public boolean isErrorDetected() {
		return errorDetected;
	}
		
	private static String StructKindToName(int kind)
	{
		switch (kind)
		{
			case Struct.None: return 	"Struct_None";
			case Struct.Int: return 	"Struct_Int";
			case Struct.Char: return 	"Struct_Char";
			case Struct.Array: return 	"Struct_Array";
			case Struct.Class: return 	"Struct_Class";
			case Struct.Bool: return 	"Struct_Bool";
		}
		assert(false) : "We should always have some of existing Kinds sent in StructKindToName function";
		return "NoSuchKind";
	}
	
	private static String ObjTypeToName(int type)
	{
		switch (type)
		{
			case Obj.NO_VALUE: return 	"Obj_NOVALUE";
			case Obj.Con: return 		"Obj_Con";
			case Obj.Var: return 		"Obj_Var";
			case Obj.Type: return 		"Obj_Type";
			case Obj.Meth: return 		"Obj_Meth";
			case Obj.Fld: return 		"Obj_Fld";
			case Obj.Elem: return 		"Obj_Elem";
			case Obj.Prog: return 		"Obj_Prog";
		}
		
		assert(false) : "We should always have some of existing Types sent in ObjTypeToName function";
		return "NoSuchType";
	}
	
	@Override
	public void visit(ProgramName ProgramName) {
		ProgramName.obj = Tab.insert(Obj.Prog, ProgramName.getPName(), Tab.noType);
		Tab.openScope(); 
	}

	@Override
	public void visit(Program Program) {
		nVars = Tab.currentScope.getnVars();
		Tab.chainLocalSymbols(Program.getProgramName().obj);
		Tab.closeScope();
		
		if (!mainFound)
		{
			report_error("Semantic Error on line " + Program.getLine()+ " : You have not defined \"void main\" function", null);
		}
	}

	@Override
	public void visit(DesigName DesigName)
	{
		DesigName.obj = Tab.find(DesigName.getDesignatorName());
	}
	
	@Override
	public void visit(Designator Designator) {
		Obj obj = Tab.find(Designator.getDesigName().getDesignatorName());

		if (Tab.noObj == obj)
		{
			report_error(
					"Semantic Error on line " + Designator.getLine() +
					" : Name \"" + Designator.getDesigName().getDesignatorName() +
					"\" is not declared! ", Designator);
			Designator.obj = Tab.noObj;
			return;
		} 
		
		if (Designator.getOptArray().struct.getKind() == Struct.Array)
		{
			if (obj.getType().getKind() != Struct.Array)
			{
				report_error(
						"Semantic Error on line " + Designator.getLine() +
						" : Variable " + Designator.getDesigName().getDesignatorName() +
						" is not an array ", Designator);
				Designator.obj = Tab.noObj;
				return;
			}
			
			Designator.obj = new Obj(Obj.Elem, obj.getName()+"_Elem", obj.getType().getElemType()); //,/* Hack */ obj.getAdr(), obj.getLevel());
			return;
		}
		
		Designator.obj = obj;
	}
	
	@Override
	public void visit(FormalParamDecl FormalParamDecl) {
		Struct TypeOfFormalParam = FormalParamDecl.getType().struct;
		if (FormalParamDecl.getOptArrayBrackets().bool)
		{
			TypeOfFormalParam = new Struct(Struct.Array, FormalParamDecl.getType().struct);
		}
		
		if (Tab.currentScope().findSymbol(FormalParamDecl.getParamName()) != null)
		{
			report_error("Semantic Error on line " + FormalParamDecl.getLine() + ": Formal parameter with name \"" + FormalParamDecl.getParamName() +"\" already defined in current scope!", null);
			FormalParamDecl.struct = Tab.noType;
			return;
		}
		
		Tab.insert(Obj.Var, FormalParamDecl.getParamName(), TypeOfFormalParam);
		FormalParamDecl.struct = TypeOfFormalParam;
		
		report_info("FormalParamDecl inserted of name " + FormalParamDecl.getParamName() + " and type "+ StructKindToName(FormalParamDecl.getType().struct.getKind()), null);
	}

	@Override
	public void visit(MethodTypeName MethodTypeName) {
        if(Tab.currentScope.findSymbol(MethodTypeName.getMethodName())!= null)
        {
              report_error("Semantic Error method named \"" + MethodTypeName.getMethodName() + "\" already exists", null);
              currentMethod = MethodTypeName.obj = null;
              return;
        }
        Struct MethodReturnType = MethodTypeName.getType().struct;
        if (MethodTypeName.getOptArrayBrackets().bool)
        {
        	MethodReturnType = new Struct(Struct.Array, MethodTypeName.getType().struct);
        }
        
        if (MethodTypeName.getMethodName().equals("main"))
        {
        	mainFound = true;
        	if (MethodReturnType != Tab.noType)
        	{
        		report_error("Semantic Error on line " + MethodTypeName.getLine() + " : Main method needs to be of type \"void\" and you have provided type " +
        	StructKindToName(MethodReturnType.getKind()), null);
        		mainFound = false;
        	}
        }

        currentMethod = Tab.insert(Obj.Meth, MethodTypeName.getMethodName(), MethodReturnType);
		MethodTypeName.obj  = currentMethod;
		
		Tab.openScope();
		report_info("Processing function " + MethodTypeName.getMethodName(), MethodTypeName);
	}

	@Override
	public void visit(MethodDecl MethodDecl) {
		if (currentMethod == null)
		{
			Tab.closeScope();
			return;
		}
		if (!returnFound && currentMethod.getType() != Tab.noType) {
			report_error("Semantic Error on line " + MethodDecl.getLine() + ": function \"" + currentMethod.getName() + "\" doesn't have return expression!", MethodDecl);
			return;
		}
		
		assert(MethodDecl.getMethodTypeName().obj == currentMethod)
			: "currentMethod should be same as object in MethodTypeName";
		
		MethodDecl.getMethodTypeName().obj.setLevel(MethodDecl.getOptFormalParamList().list.size());
		
		Tab.chainLocalSymbols(MethodDecl.getMethodTypeName().obj);
		Tab.closeScope();
				
		// Object[] formalParams = MethodDecl.getMethodTypeName().obj.getLocalSymbols().toArray();
		
		returnFound = false;
		currentMethod = null;
	}

	@Override
	public void visit(FormalParamListOpt FormalParamListOpt)
	{
		FormalParamListOpt.list = FormalParamListOpt.getFormalParamList().list;
	}
	
	@Override
	public void visit(NoFormalParam NoFormalParam)
	{
		NoFormalParam.list = new java.util.ArrayList<Struct>();
	}
	
	@Override
	public void visit(FormalParamDeclList FormalParamDeclList)
	{
		FormalParamDeclList.getFormalParamList().list.add(FormalParamDeclList.getFormalParamDecl().struct);
		FormalParamDeclList.list = FormalParamDeclList.getFormalParamList().list;
		report_info("Formal param \"" + StructKindToName(FormalParamDeclList.getFormalParamDecl().struct.getKind()) + "\" defined on line "+ FormalParamDeclList.getLine(), null);
	}
	
	public void visit(SingleFormalParamDecl SingleFormalParamDecl)
	{
		SingleFormalParamDecl.list = new java.util.ArrayList();
		SingleFormalParamDecl.list.add(SingleFormalParamDecl.getFormalParamDecl().struct);
		report_info("Formal param \"" + StructKindToName(SingleFormalParamDecl.getFormalParamDecl().struct.getKind()) + "\" on line "+ SingleFormalParamDecl.getLine(), null);
	}
	
	@Override
	public void visit(SimpleType SimpleType) {
		SimpleType.bool = false;
	}

	@Override
	public void visit(ArrayType ArrayType) {
		ArrayType.bool = true;
	}
	
	@Override
	public void visit(AssignExpression AssignExpression)
	{
		AssignExpression.obj = AssignExpression.getConst().obj;
	}
	
	@Override
	public void visit(NoAssignExpr NoAssignExpr)
	{
		NoAssignExpr.obj = Tab.noObj;
	}
	
	@Override
	public void visit(Var Var)
	{
		Struct VariableType = currentDeclTypeStruct;
		if(Var.getOptArrayBrackets().bool)
		{
			report_info("Array \""+ Var.getVarName() + "\" declared on line " + Var.getLine() +
					" of type " + StructKindToName(currentDeclTypeStruct.getKind()), Var);
			VariableType = new Struct(Struct.Array, currentDeclTypeStruct);
		} else
		{
			report_info("Variable \""+ Var.getVarName() + "\" declared on line " + Var.getLine() +
					" of type " + StructKindToName(currentDeclTypeStruct.getKind()), Var);
		}
		
		if (Var.getOptValueAssign().obj != Tab.noObj)
		{
			if (!IsSecondTypeCompatibleWithFirst(VariableType, Var.getOptValueAssign().obj.getType()))
			{
				report_error("Semantic Error on line " + Var.getLine() + " : Variable \"" + Var.getVarName() + "\" of type " +
						StructKindToName(VariableType.getKind())+" has assigned value of type " +
						StructKindToName(Var.getOptValueAssign().obj.getType().getKind()), null);
			}
		}
		
		if (Tab.currentScope().findSymbol(Var.getVarName()) != null)
		{
			report_error("Semantic Error on line " + Var.getLine() + " : Variable \"" + Var.getVarName() + "\" is already defined in current scope", null);
			return;
		}

		Var.obj = Tab.insert(isCurrentTypeConst?Obj.Con:Obj.Var, Var.getVarName(), VariableType);
		
		if (isCurrentTypeConst && Var.getOptValueAssign().obj != Tab.noObj)
 		{
 			Var.obj.setAdr(currentAssignObject.getAdr());
 		}
	}
	
	@Override
	public void visit(VarDeclNoErr VarDeclNoErr)
	{
		currentDeclTypeStruct = null;
		isCurrentTypeConst = false;
	}
	
	@Override
	public void visit(VarDeclError VarDeclError)
	{
		currentDeclTypeStruct = null;
		isCurrentTypeConst = false;
	}
	
	@Override
	public void visit(NoArrayIndexer NoArrayIndexer) {
		NoArrayIndexer.struct = Tab.noType;
	}

	@Override
	public void visit(ArrayIndexer ArrayIndexer) {
		if (ArrayIndexer.getExpr().struct.getKind() != Struct.Int)
		{
			report_error("Semantic Error on line " + ArrayIndexer.getLine() + " : arrays can only be indexed with integers, and you are trying to index with type "
					+ StructKindToName(ArrayIndexer.getExpr().struct.getKind()), null);
			ArrayIndexer.struct = Tab.noType;
			return;
		}
		
		ArrayIndexer.struct = new Struct(Struct.Array);;
	}

	@Override
	public void visit(ConstBool ConstBool) {
		ConstBool.obj = new Obj(Obj.Con, "ConstBool", new Struct(Struct.Bool));;
		ConstBool.obj.setAdr(ConstBool.getBooll()?1:0);
		currentAssignObject = ConstBool.obj;
	}

	@Override
	public void visit(ConstChar ConstChar) {
		ConstChar.obj = new Obj(Obj.Con, "ConstChar", Tab.charType);
		ConstChar.obj.setAdr(ConstChar.getCharr());
		currentAssignObject = ConstChar.obj;
	}

	@Override
	public void visit(ConstNum ConstNum) {
		ConstNum.obj = new Obj(Obj.Con, "ConstInt", Tab.intType);
		ConstNum.obj.setAdr(ConstNum.getNumm());
		currentAssignObject = ConstNum.obj;
	}

	@Override
	public void visit(NewType NewType) {
		if (NewType.getOptArray().struct.getKind() != Struct.Array)
		{
			report_error("Semantic Error on line " + NewType.getLine() + " : operator NEW can only be used with array types (Type you have provided is "
					+ StructKindToName(NewType.getOptArray().struct.getKind()) +")", null);
			NewType.struct = Tab.noType;
			return;
		}
		NewType.struct = new Struct(Struct.Array, NewType.getType().struct);
	}

	@Override
	public void visit(ParenExpr ParenExpr) {
		ParenExpr.struct = ParenExpr.getExpr().struct;
	}

	@Override
	public void visit(ConstVar ConstVar) {
		ConstVar.struct = ConstVar.getConst().obj.getType();
	}

	@Override
	public void visit(SingleFactor SingleFactor) {
		SingleFactor.struct = SingleFactor.getFactor().struct;
	}
	
	@Override
	public void visit(MinusFactor MinusFactor)
	{
		MinusFactor.struct = MinusFactor.getFactor().struct;
	}

	@Override
	public void visit(FactorMulops FactorMulops) {
		Struct factor = FactorMulops.getFactor().struct;
		Struct factorMulList = FactorMulops.getFactorMulopList().struct;
		if (factor.equals(factorMulList) && factor == Tab.intType)
		{
			FactorMulops.struct = factor;
			return;
		}
		
		FactorMulops.struct = Tab.noType;
		report_error("Semantic Error on line "+ FactorMulops.getLine() +
				" : incompatible types in multiplication expression ( " + StructKindToName(factor.getKind())
				+ " and mul " + StructKindToName(factorMulList.getKind()) + " )", FactorMulops);
	}

	@Override
	public void visit(Term Term) {
		Term.struct = Term.getFactorMulopList().struct;
	}

	@Override
	public void visit(SingleTerm SingleTerm) {
		SingleTerm.struct = SingleTerm.getTerm().struct;
	}

	@Override
	public void visit(TermAddops TermAddops) {
		Struct term = TermAddops.getTerm().struct;
		Struct termSumList = TermAddops.getTermAddopList().struct;
		
		if (term.equals(termSumList) && term == Tab.intType)
		{
			TermAddops.struct = term;
			return;
		}
		
		TermAddops.struct = Tab.noType;
		report_error("Semantic Error on line "+ TermAddops.getLine() +
				" : incompatible types in addition expression ( " +StructKindToName(term.getKind()) + " and sum " + StructKindToName(termSumList.getKind()) + " )", TermAddops);
	}

	@Override
	public void visit(FuncCall FuncCall) {
		Obj function = FuncCall.getDesignator().obj;
		int numOfParams = FuncCall.getOptArgumentParamList().list.size();
		if (Obj.Meth != function.getKind())
		{
			report_error("Semantic Error on line " + FuncCall.getLine() +
					" : \"" + function.getName() + "\" is not a function! (It is of kind "+ StructKindToName(function.getKind()) + ")", FuncCall);
			FuncCall.struct = Tab.noType;
			return;
		}
		
		if ( numOfParams!= function.getLevel())
		{
			String insuficient = " insufficient number of ";
			if (numOfParams > function.getLevel())
				insuficient = " too many ";
			report_error("Semantic Error on line " + FuncCall.getLine() + " : \"" + function.getName() + 
					"\" is called with" + insuficient +" parameters! (It should have " + function.getLevel() +
					" and you have provided " + FuncCall.getOptArgumentParamList().list.size() + " parameters)", FuncCall);
			FuncCall.struct = Tab.noType;
			return;
		}
		
		--numOfParams;
		int currentParameterIndex = 0;
		Object[] formalParams = function.getLocalSymbols().toArray();
		
		
		report_info("Function level " + function.getLevel() + " function local symbols " + formalParams.length, null);
		/*
		for (Struct argumentProvided : (ArrayList<Struct>)FuncCall.getOptArgumentParamList().list)
		{
			report_info("Arg provided " + StructKindToName(argumentProvided.getKind()) + " Formal Arg " +
						StructKindToName(((Obj)formalParams[numOfParams- currentParameterIndex]).getType().getKind()), null);
			++currentParameterIndex;
		}
		currentParameterIndex = 0;
		*/
		for (Struct argumentProvided : (ArrayList<Struct>)FuncCall.getOptArgumentParamList().list)
		{
			Obj formalParam = (Obj)formalParams[numOfParams - currentParameterIndex];
			++currentParameterIndex;
			
			if (!IsSecondTypeCompatibleWithFirst(formalParam.getType(), argumentProvided))
			{
				report_error("Semantic Error on line " + FuncCall.getLine() +" : \"" + function.getName() + 
						"\" was called with parameter "+ currentParameterIndex + " of type "+ StructKindToName(argumentProvided.getKind()) +
						", but " +StructKindToName(formalParam.getType().getKind()) + " was expected" , FuncCall);
				FuncCall.struct = Tab.noType;
				return;
			}
		}
		
		report_info("Function " + function.getName() + " call was found on line " + FuncCall.getLine(), FuncCall);
		FuncCall.struct = function.getType();
	}

	@Override
	public void visit(ArgumentParams ArgumentParams)
	{
		ArgumentParams.list = ArgumentParams.getArgumentParamList().list;
	}
	
	@Override
	public void visit(NoArgumentParams NoArgumentParams)
	{
		NoArgumentParams.list = new java.util.ArrayList();
	}
	
	@Override
	public void visit(MultipleArgumentParams MultipleArgumentParams)
	{
		MultipleArgumentParams.getArgumentParamList().list.add(MultipleArgumentParams.getExpr().struct);
		MultipleArgumentParams.list = MultipleArgumentParams.getArgumentParamList().list;
		report_info("Argument \"" + StructKindToName(MultipleArgumentParams.getExpr().struct.getKind()) + "\" on line "+ MultipleArgumentParams.getLine(), null);
	}
	
	@Override
	public void visit(ArgumentParam ArgumentParam)
	{
		ArgumentParam.list = new java.util.ArrayList();
		ArgumentParam.list.add(ArgumentParam.getExpr().struct);
		report_info("Argument \"" + StructKindToName(ArgumentParam.getExpr().struct.getKind()) + "\" on line "+ ArgumentParam.getLine(), null);

	}
	
	@Override
	public void visit(Expr Expr) {
		Expr.struct = Expr.getTermAddopList().struct;
	}
	
	@Override
	public void visit(DefVarWithOptPostfixOp DefVarWithOptPostfixOp) {
		DefVarWithOptPostfixOp.struct = DefVarWithOptPostfixOp.getDesigWithOptPostfixOperation().obj.getType();
	}
	
	@Override
	public void visit(DecOperation DecOperation)
	{
		DecOperation.obj = DecOperation.getDesignator().obj;
		if (!IsObjectOfTypeInt(DecOperation.getDesignator().obj))
		{
			report_error("Semantic Error on line " + DecOperation.getLine() + " : Postfix operation cannot be used on object of kind " +
					ObjTypeToName(DecOperation.getDesignator().obj.getKind()) + " and type "+ StructKindToName(DecOperation.getDesignator().obj.getType().getKind()) , null);
		}
	}
	
	@Override
	public void visit(IncOperation IncOperation)
	{
		IncOperation.obj = IncOperation.getDesignator().obj;
		if (!IsObjectOfTypeInt(IncOperation.getDesignator().obj))
		{
			report_error("Semantic Error on line " + IncOperation.getLine() + " : Postfix operation cannot be used on object of kind " +
					ObjTypeToName(IncOperation.getDesignator().obj.getKind()) + " and type "+ StructKindToName(IncOperation.getDesignator().obj.getType().getKind()) , null);
		}
	}
	
	@Override
	public void visit(NoPosfixOperation NoPosfixOperation)
	{
		NoPosfixOperation.obj = NoPosfixOperation.getDesignator().obj;
	}
	
	public static boolean IsObjectOfTypeInt(Obj obj)
	{
		if ((obj.getKind() == Obj.Var || obj.getKind() == Obj.Elem) && obj.getType() == Tab.intType)
			return true;
		
		return false;
	}
	
	public static boolean IsSecondTypeCompatibleWithFirst(Struct first, Struct second)
	{
		if (second.assignableTo(first))
			return true;
		
		if (second.getKind() == first.getKind()) {
			if (first.getKind() != Struct.Array)
				return true;
			
			return IsSecondTypeCompatibleWithFirst(first.getElemType(), second.getElemType());
		}
		
		return false;
	}
	
	@Override
	public void visit(AssignmentStmt AssignmentStmt) {
		Struct LeftFromAssignType = AssignmentStmt.getDesignator().obj.getType();
		Struct RightFromAssignType = AssignmentStmt.getAssignExpr().getExprOrError().struct;
		
		if (!IsSecondTypeCompatibleWithFirst(LeftFromAssignType, RightFromAssignType))
		{
			report_error("Semantic Error on line " + AssignmentStmt.getLine() +" : incompatible types in assignment ("+
					StructKindToName(RightFromAssignType.getKind()) + " is not assignable to "+
					StructKindToName(LeftFromAssignType.getKind()) + ")", AssignmentStmt);
		}
		
		if (AssignmentStmt.getDesignator().obj.getKind() == Obj.Con)
		{
			report_error("Semantic Error on line " + AssignmentStmt.getLine() +
					" : you cannot assign to once const declared variable "+
					AssignmentStmt.getDesignator().getDesigName().getDesignatorName() + " ("+
					" Types are however compatible "+StructKindToName(LeftFromAssignType.getKind())+ ")" ,null);
		}
	}
	
	@Override
	public void visit(ReturnExpr ReturnExpr) {
		returnFound = true;
		Struct DefinedReturnType = currentMethod.getType();
		Struct ActualReturningType = ReturnExpr.getExpr().struct;
		
		if (!IsSecondTypeCompatibleWithFirst(DefinedReturnType, ActualReturningType)) {
			report_error("Semantic Error on line " + ReturnExpr.getLine() +
					" : Type of expression in return statement is incompatible with return value type of method "
					+ currentMethod.getName() +" (Return expression of type " + StructKindToName(ReturnExpr.getExpr().struct.getKind()) +
					", current method needs type "+ StructKindToName(currentMethod.getType().getKind()) + ")", ReturnExpr);
			return;
		}
	}
	@Override
	public void visit(NoCommaNumber NoCommaNumber) {
		NoCommaNumber.struct = Tab.noType;
	}

	@Override
	public void visit(PrintStmt PrintStmt)
	{
		if (PrintStmt.getExpr().struct != Tab.intType && PrintStmt.getExpr().struct != Tab.charType)
		{
			report_error("Semantic Error on line " + PrintStmt.getLine() + ", print statement can only be userd on int or char" +
					" you have provided expression of type " + StructKindToName(PrintStmt.getExpr().struct.getKind()), null);
		}
	}
	
	@Override
	public void visit(ReadStmt ReadStmt)
	{
		if (ReadStmt.getDesignator().obj.getType() != Tab.intType && ReadStmt.getDesignator().obj.getType() != Tab.charType)
		{
			report_error("Semantic Error on line " + ReadStmt.getLine() + ", read statement can only be userd on int or char" +
					" you have provided expression of type " + StructKindToName(ReadStmt.getDesignator().obj.getType().getKind()), null);
		}
	}
	
	@Override
	public void visit(CommaNumber CommaNumber) {
		if (CommaNumber.getExpr().struct.getKind() != Struct.Int)
		{
			report_error("Semantic Error on line " + CommaNumber.getLine() +" : second parameter in print needs to be of type int ("+
					"you have used expression which is returning type"+ StructKindToName(CommaNumber.getExpr().struct.getKind()) +")", null);
			CommaNumber.struct = Tab.noType;
			return;
		}
		CommaNumber.struct = Tab.intType;
	}
	
	@Override
	public void visit(ExprFuncCall ExprFuncCall) {
		ExprFuncCall.struct = ExprFuncCall.getFuncCall().struct;
		
		if (ExprFuncCall.struct == Tab.noType)
		{
			report_error("Semantic Error on line " + ExprFuncCall.getLine() +
					" : function \"" + ExprFuncCall.getFuncCall().getDesignator().getDesigName().getDesignatorName() +
					"\" is of type void and cannot be used in expresion", null);
		}
	}

	@Override
	public void visit(Expression Expression) {
		Expression.struct = Expression.getExpr().struct;
	}

	@Override
	public void visit(VoidType VoidType) {
		VoidType.struct = Tab.noType;
	}
	
	@Override
	public void visit(NotVoidType NotVoidType) {
		NotVoidType.struct = Tab.noType;
		Obj typeNode = Tab.find(NotVoidType.getTypeName());
		
		if (typeNode == null || typeNode == Tab.noObj) {
			report_error("Semnatic Error on line "+ NotVoidType.getLine() + " : Type \"" + NotVoidType.getTypeName() + "\" not found in symbol table ", NotVoidType);
			return;
		}
		
		if (Obj.Type != typeNode.getKind()) {
			report_error("Semantic Error on line "+ NotVoidType.getLine() + " : Name \""+ NotVoidType.getTypeName() + "\" does not represent type", NotVoidType);
			return;
		}
		
		NotVoidType.struct = typeNode.getType();
		isCurrentTypeConst = false;
		currentDeclTypeStruct = NotVoidType.struct;
	}

	@Override
	public void visit(ConstType ConstType)
	{
		ConstType.struct = Tab.noType;
		Obj typeNode = Tab.find(ConstType.getTypeName());
		
		if (typeNode == null || typeNode == Tab.noObj) {
			report_error("Semnatic Error on line "+ ConstType.getLine() + " : Type \"" + ConstType.getTypeName() + "\" not found in symbol table ", ConstType);
			return;
		}
		
		if (Obj.Type != typeNode.getKind()) {
			report_error("Semantic Error on line "+ ConstType.getLine() + " : Name \""+ ConstType.getTypeName() + "\" does not represent type", ConstType);
			return;
		}
		
		isCurrentTypeConst = true;
		ConstType.struct = typeNode.getType();
		currentDeclTypeStruct = ConstType.struct;
	}
	
	@Override
	public void visit(CondExpr CondExpr)
	{
		CondExpr.struct = Tab.noType;
		if (CondExpr.getExpr().struct.getKind() != Struct.Bool)
		{
			report_error("Semantic Error on line "+ CondExpr.getLine() + " : expression is not of type bool ("+
						"it is of type " + StructKindToName(CondExpr.getExpr().struct.getKind()) + ")", CondExpr);
			return;
		}
		
		CondExpr.struct = CondExpr.getExpr().struct;
	}
	
	@Override
	public void visit(CondExprComparison CondExprComparison)
	{
		CondExprComparison.struct = Tab.noType;
		if (CondExprComparison.getExpr().struct.getKind() != Struct.Int ||
				CondExprComparison.getExpr1().struct.getKind() != Struct.Int	)
		{
			report_error("Semantic Error on line "+ CondExprComparison.getLine() + " : both expressions need to be of type int in order to compare them ("+
						" it is of type Expr1: " + StructKindToName(CondExprComparison.getExpr().struct.getKind()) + " and Expr2: "+
					StructKindToName(CondExprComparison.getExpr1().struct.getKind()) + ")", CondExprComparison);
			return;
		}
		
		CondExprComparison.struct = new Struct(Struct.Bool);
	}
}
