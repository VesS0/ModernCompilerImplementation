// generated with ast extension for cup
// version 0.8
// 23/5/2018 3:50:52


package rs.ac.bg.etf.pp1.ast;

public class MultipleArgumentParams extends ArgumentParamList {

    private Expr Expr;
    private ArgumentParamList ArgumentParamList;

    public MultipleArgumentParams (Expr Expr, ArgumentParamList ArgumentParamList) {
        this.Expr=Expr;
        if(Expr!=null) Expr.setParent(this);
        this.ArgumentParamList=ArgumentParamList;
        if(ArgumentParamList!=null) ArgumentParamList.setParent(this);
    }

    public Expr getExpr() {
        return Expr;
    }

    public void setExpr(Expr Expr) {
        this.Expr=Expr;
    }

    public ArgumentParamList getArgumentParamList() {
        return ArgumentParamList;
    }

    public void setArgumentParamList(ArgumentParamList ArgumentParamList) {
        this.ArgumentParamList=ArgumentParamList;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(Expr!=null) Expr.accept(visitor);
        if(ArgumentParamList!=null) ArgumentParamList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(Expr!=null) Expr.traverseTopDown(visitor);
        if(ArgumentParamList!=null) ArgumentParamList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(Expr!=null) Expr.traverseBottomUp(visitor);
        if(ArgumentParamList!=null) ArgumentParamList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("MultipleArgumentParams(\n");

        if(Expr!=null)
            buffer.append(Expr.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ArgumentParamList!=null)
            buffer.append(ArgumentParamList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [MultipleArgumentParams]");
        return buffer.toString();
    }
}
