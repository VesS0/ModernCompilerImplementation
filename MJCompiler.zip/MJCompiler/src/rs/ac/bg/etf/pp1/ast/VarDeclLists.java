// generated with ast extension for cup
// version 0.8
// 23/5/2018 3:50:52


package rs.ac.bg.etf.pp1.ast;

public class VarDeclLists extends OptDeclList {

    private Decl Decl;
    private OptDeclList OptDeclList;

    public VarDeclLists (Decl Decl, OptDeclList OptDeclList) {
        this.Decl=Decl;
        if(Decl!=null) Decl.setParent(this);
        this.OptDeclList=OptDeclList;
        if(OptDeclList!=null) OptDeclList.setParent(this);
    }

    public Decl getDecl() {
        return Decl;
    }

    public void setDecl(Decl Decl) {
        this.Decl=Decl;
    }

    public OptDeclList getOptDeclList() {
        return OptDeclList;
    }

    public void setOptDeclList(OptDeclList OptDeclList) {
        this.OptDeclList=OptDeclList;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(Decl!=null) Decl.accept(visitor);
        if(OptDeclList!=null) OptDeclList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(Decl!=null) Decl.traverseTopDown(visitor);
        if(OptDeclList!=null) OptDeclList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(Decl!=null) Decl.traverseBottomUp(visitor);
        if(OptDeclList!=null) OptDeclList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("VarDeclLists(\n");

        if(Decl!=null)
            buffer.append(Decl.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(OptDeclList!=null)
            buffer.append(OptDeclList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [VarDeclLists]");
        return buffer.toString();
    }
}
