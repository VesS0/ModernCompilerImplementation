// generated with ast extension for cup
// version 0.8
// 23/5/2018 3:50:52


package rs.ac.bg.etf.pp1.ast;

public class DefVarWithOptPostfixOp extends Factor {

    private DesigWithOptPostfixOperation DesigWithOptPostfixOperation;

    public DefVarWithOptPostfixOp (DesigWithOptPostfixOperation DesigWithOptPostfixOperation) {
        this.DesigWithOptPostfixOperation=DesigWithOptPostfixOperation;
        if(DesigWithOptPostfixOperation!=null) DesigWithOptPostfixOperation.setParent(this);
    }

    public DesigWithOptPostfixOperation getDesigWithOptPostfixOperation() {
        return DesigWithOptPostfixOperation;
    }

    public void setDesigWithOptPostfixOperation(DesigWithOptPostfixOperation DesigWithOptPostfixOperation) {
        this.DesigWithOptPostfixOperation=DesigWithOptPostfixOperation;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(DesigWithOptPostfixOperation!=null) DesigWithOptPostfixOperation.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(DesigWithOptPostfixOperation!=null) DesigWithOptPostfixOperation.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(DesigWithOptPostfixOperation!=null) DesigWithOptPostfixOperation.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("DefVarWithOptPostfixOp(\n");

        if(DesigWithOptPostfixOperation!=null)
            buffer.append(DesigWithOptPostfixOperation.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [DefVarWithOptPostfixOp]");
        return buffer.toString();
    }
}
