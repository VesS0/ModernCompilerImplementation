// generated with ast extension for cup
// version 0.8
// 23/5/2018 3:50:52


package rs.ac.bg.etf.pp1.ast;

public class CondAndLists extends CondAndList {

    private CondAndList CondAndList;
    private Condition Condition;

    public CondAndLists (CondAndList CondAndList, Condition Condition) {
        this.CondAndList=CondAndList;
        if(CondAndList!=null) CondAndList.setParent(this);
        this.Condition=Condition;
        if(Condition!=null) Condition.setParent(this);
    }

    public CondAndList getCondAndList() {
        return CondAndList;
    }

    public void setCondAndList(CondAndList CondAndList) {
        this.CondAndList=CondAndList;
    }

    public Condition getCondition() {
        return Condition;
    }

    public void setCondition(Condition Condition) {
        this.Condition=Condition;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(CondAndList!=null) CondAndList.accept(visitor);
        if(Condition!=null) Condition.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(CondAndList!=null) CondAndList.traverseTopDown(visitor);
        if(Condition!=null) Condition.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(CondAndList!=null) CondAndList.traverseBottomUp(visitor);
        if(Condition!=null) Condition.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("CondAndLists(\n");

        if(CondAndList!=null)
            buffer.append(CondAndList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(Condition!=null)
            buffer.append(Condition.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [CondAndLists]");
        return buffer.toString();
    }
}
