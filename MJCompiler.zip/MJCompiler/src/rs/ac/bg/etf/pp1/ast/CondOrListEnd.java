// generated with ast extension for cup
// version 0.8
// 23/5/2018 3:50:52


package rs.ac.bg.etf.pp1.ast;

public class CondOrListEnd implements SyntaxNode {

    private SyntaxNode parent;
    private int line;
    public rs.etf.pp1.symboltable.concepts.Struct struct = null;

    private CondOrList CondOrList;

    public CondOrListEnd (CondOrList CondOrList) {
        this.CondOrList=CondOrList;
        if(CondOrList!=null) CondOrList.setParent(this);
    }

    public CondOrList getCondOrList() {
        return CondOrList;
    }

    public void setCondOrList(CondOrList CondOrList) {
        this.CondOrList=CondOrList;
    }

    public SyntaxNode getParent() {
        return parent;
    }

    public void setParent(SyntaxNode parent) {
        this.parent=parent;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line=line;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(CondOrList!=null) CondOrList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(CondOrList!=null) CondOrList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(CondOrList!=null) CondOrList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("CondOrListEnd(\n");

        if(CondOrList!=null)
            buffer.append(CondOrList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [CondOrListEnd]");
        return buffer.toString();
    }
}
