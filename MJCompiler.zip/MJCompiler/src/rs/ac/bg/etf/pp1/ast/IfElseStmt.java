// generated with ast extension for cup
// version 0.8
// 23/5/2018 3:50:52


package rs.ac.bg.etf.pp1.ast;

public class IfElseStmt extends Statement {

    private StatmenetIfElse StatmenetIfElse;

    public IfElseStmt (StatmenetIfElse StatmenetIfElse) {
        this.StatmenetIfElse=StatmenetIfElse;
        if(StatmenetIfElse!=null) StatmenetIfElse.setParent(this);
    }

    public StatmenetIfElse getStatmenetIfElse() {
        return StatmenetIfElse;
    }

    public void setStatmenetIfElse(StatmenetIfElse StatmenetIfElse) {
        this.StatmenetIfElse=StatmenetIfElse;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(StatmenetIfElse!=null) StatmenetIfElse.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(StatmenetIfElse!=null) StatmenetIfElse.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(StatmenetIfElse!=null) StatmenetIfElse.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("IfElseStmt(\n");

        if(StatmenetIfElse!=null)
            buffer.append(StatmenetIfElse.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [IfElseStmt]");
        return buffer.toString();
    }
}
