// generated with ast extension for cup
// version 0.8
// 23/5/2018 3:50:53


package rs.ac.bg.etf.pp1.ast;

public abstract class VisitorAdaptor implements Visitor { 

    public void visit(ExprOrError ExprOrError) { }
    public void visit(OptFormalParamList OptFormalParamList) { }
    public void visit(Mulop Mulop) { }
    public void visit(OptArrayBrackets OptArrayBrackets) { }
    public void visit(OptValueAssign OptValueAssign) { }
    public void visit(OptArray OptArray) { }
    public void visit(OptArgumentParamList OptArgumentParamList) { }
    public void visit(Addop Addop) { }
    public void visit(OptStatementList OptStatementList) { }
    public void visit(Factor Factor) { }
    public void visit(DesigWithOptPostfixOperation DesigWithOptPostfixOperation) { }
    public void visit(TermAddopList TermAddopList) { }
    public void visit(Condition Condition) { }
    public void visit(Compareop Compareop) { }
    public void visit(StatmenetIfElse StatmenetIfElse) { }
    public void visit(ArgumentParamList ArgumentParamList) { }
    public void visit(OptDeclList OptDeclList) { }
    public void visit(OptCommaNumber OptCommaNumber) { }
    public void visit(VarDeclList VarDeclList) { }
    public void visit(FormalParamList FormalParamList) { }
    public void visit(DesignatorStatement DesignatorStatement) { }
    public void visit(Const Const) { }
    public void visit(FactorMulopList FactorMulopList) { }
    public void visit(OptMethodDeclList OptMethodDeclList) { }
    public void visit(Decl Decl) { }
    public void visit(Statement Statement) { }
    public void visit(CondAndList CondAndList) { }
    public void visit(Type Type) { }
    public void visit(CondOrList CondOrList) { }
    public void visit(ArgumentParam ArgumentParam) { visit(); }
    public void visit(MultipleArgumentParams MultipleArgumentParams) { visit(); }
    public void visit(NoArgumentParams NoArgumentParams) { visit(); }
    public void visit(ArgumentParams ArgumentParams) { visit(); }
    public void visit(NoStatement NoStatement) { visit(); }
    public void visit(StatementList StatementList) { visit(); }
    public void visit(FormalParamDecl FormalParamDecl) { visit(); }
    public void visit(ErrorInFormalParamDecl ErrorInFormalParamDecl) { visit(); }
    public void visit(SingleFormalParamDecl SingleFormalParamDecl) { visit(); }
    public void visit(FormalParamDeclList FormalParamDeclList) { visit(); }
    public void visit(NoFormalParam NoFormalParam) { visit(); }
    public void visit(FormalParamError FormalParamError) { visit(); }
    public void visit(FormalParamListOpt FormalParamListOpt) { visit(); }
    public void visit(MethodTypeName MethodTypeName) { visit(); }
    public void visit(MethodDecl MethodDecl) { visit(); }
    public void visit(NoMethodDecl NoMethodDecl) { visit(); }
    public void visit(MethodDeclList MethodDeclList) { visit(); }
    public void visit(VoidType VoidType) { visit(); }
    public void visit(ConstType ConstType) { visit(); }
    public void visit(NotVoidType NotVoidType) { visit(); }
    public void visit(SimpleType SimpleType) { visit(); }
    public void visit(ArrayType ArrayType) { visit(); }
    public void visit(Var Var) { visit(); }
    public void visit(ErrorCommaVar ErrorCommaVar) { visit(); }
    public void visit(SingleVar SingleVar) { visit(); }
    public void visit(Vars Vars) { visit(); }
    public void visit(VarDeclError VarDeclError) { visit(); }
    public void visit(VarDeclNoErr VarDeclNoErr) { visit(); }
    public void visit(NoDecl NoDecl) { visit(); }
    public void visit(VarDeclLists VarDeclLists) { visit(); }
    public void visit(MulopMod MulopMod) { visit(); }
    public void visit(MulopDiv MulopDiv) { visit(); }
    public void visit(MulopMul MulopMul) { visit(); }
    public void visit(AddopSub AddopSub) { visit(); }
    public void visit(AddopAdd AddopAdd) { visit(); }
    public void visit(NoArrayIndexer NoArrayIndexer) { visit(); }
    public void visit(ArrayIndexer ArrayIndexer) { visit(); }
    public void visit(DesigName DesigName) { visit(); }
    public void visit(Designator Designator) { visit(); }
    public void visit(ConstBool ConstBool) { visit(); }
    public void visit(ConstChar ConstChar) { visit(); }
    public void visit(ConstNum ConstNum) { visit(); }
    public void visit(ExprFuncCall ExprFuncCall) { visit(); }
    public void visit(DefVarWithOptPostfixOp DefVarWithOptPostfixOp) { visit(); }
    public void visit(NewType NewType) { visit(); }
    public void visit(ParenExpr ParenExpr) { visit(); }
    public void visit(ConstVar ConstVar) { visit(); }
    public void visit(MinusFactor MinusFactor) { visit(); }
    public void visit(SingleFactor SingleFactor) { visit(); }
    public void visit(FactorMulops FactorMulops) { visit(); }
    public void visit(Term Term) { visit(); }
    public void visit(SingleTerm SingleTerm) { visit(); }
    public void visit(TermAddops TermAddops) { visit(); }
    public void visit(Expr Expr) { visit(); }
    public void visit(NoPosfixOperation NoPosfixOperation) { visit(); }
    public void visit(IncOperation IncOperation) { visit(); }
    public void visit(DecOperation DecOperation) { visit(); }
    public void visit(Err Err) { visit(); }
    public void visit(Expression Expression) { visit(); }
    public void visit(FuncCall FuncCall) { visit(); }
    public void visit(NoAssignExpr NoAssignExpr) { visit(); }
    public void visit(AssignExpression AssignExpression) { visit(); }
    public void visit(AssignExpr AssignExpr) { visit(); }
    public void visit(StmtFuncCall StmtFuncCall) { visit(); }
    public void visit(PostfixStmt PostfixStmt) { visit(); }
    public void visit(AssignmentStmt AssignmentStmt) { visit(); }
    public void visit(NoCommaNumber NoCommaNumber) { visit(); }
    public void visit(CommaNumber CommaNumber) { visit(); }
    public void visit(LessEqual LessEqual) { visit(); }
    public void visit(Less Less) { visit(); }
    public void visit(GreaterEqual GreaterEqual) { visit(); }
    public void visit(Greater Greater) { visit(); }
    public void visit(NotEqual NotEqual) { visit(); }
    public void visit(Equal Equal) { visit(); }
    public void visit(CondExprComparison CondExprComparison) { visit(); }
    public void visit(CondExpr CondExpr) { visit(); }
    public void visit(SingleCondition SingleCondition) { visit(); }
    public void visit(CondAndLists CondAndLists) { visit(); }
    public void visit(CondAndListEnd CondAndListEnd) { visit(); }
    public void visit(SingleCondAndList SingleCondAndList) { visit(); }
    public void visit(CondOrLists CondOrLists) { visit(); }
    public void visit(CondOrListEnd CondOrListEnd) { visit(); }
    public void visit(IfErrorClause IfErrorClause) { visit(); }
    public void visit(IfClauseStmt IfClauseStmt) { visit(); }
    public void visit(IfClause IfClause) { visit(); }
    public void visit(IfElseClauseError IfElseClauseError) { visit(); }
    public void visit(IfClauseError IfClauseError) { visit(); }
    public void visit(IfElseClause IfElseClause) { visit(); }
    public void visit(IfClausee IfClausee) { visit(); }
    public void visit(BraceStatement BraceStatement) { visit(); }
    public void visit(IfElseStmt IfElseStmt) { visit(); }
    public void visit(ReturnExpr ReturnExpr) { visit(); }
    public void visit(ReturnVoid ReturnVoid) { visit(); }
    public void visit(PrintStmt PrintStmt) { visit(); }
    public void visit(ReadStmt ReadStmt) { visit(); }
    public void visit(DesignatorStmt DesignatorStmt) { visit(); }
    public void visit(ProgramName ProgramName) { visit(); }
    public void visit(Program Program) { visit(); }


    public void visit() { }
}
